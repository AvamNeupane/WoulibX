// WoulibX App JavaScript

document.addEventListener("DOMContentLoaded", function () {
  // Trip type toggle functionality
  const tripOptions = document.querySelectorAll(".trip-option");

  tripOptions.forEach((option) => {
    option.addEventListener("click", function () {
      // Remove active class from all options
      tripOptions.forEach((opt) => {
        opt.classList.remove("active");
        opt.querySelector(".radio-button").classList.remove("active");
      });

      // Add active class to clicked option
      this.classList.add("active");
      this.querySelector(".radio-button").classList.add("active");
    });
  });

  // Form field interactions
  const formFields = document.querySelectorAll(".form-field");

  formFields.forEach((field) => {
    field.addEventListener("click", function () {
      // Add focus styling
      this.style.borderColor = "#43C59E";
      this.style.backgroundColor = "#fff";

      // Remove focus from other fields
      formFields.forEach((otherField) => {
        if (otherField !== this) {
          otherField.style.borderColor = "#000";
          otherField.style.backgroundColor = "#f8f8f8";
        }
      });
    });
  });

  // Search button functionality
  const searchBtn = document.querySelector(".search-btn");
  searchBtn.addEventListener("click", function () {
    // Add loading state
    const originalText = this.textContent;
    this.textContent = "Searching...";
    this.disabled = true;

    // Simulate search (remove in real implementation)
    setTimeout(() => {
      this.textContent = originalText;
      this.disabled = false;
      alert("Search functionality would be implemented here!");
    }, 2000);
  });

  // Mission statement button
  const missionBtn = document.querySelector(".mission-btn");
  if (missionBtn) {
    missionBtn.addEventListener("click", function () {
      alert("Mission statement page would open here!");
    });
  }

  // Book now button
  const bookNowBtn = document.querySelector(".book-now-btn");
  if (bookNowBtn) {
    bookNowBtn.addEventListener("click", function () {
      alert("Booking flow would start here!");
    });
  }

  // Store buttons functionality
  const storeButtons = document.querySelectorAll(".store-btn");
  storeButtons.forEach((btn) => {
    btn.addEventListener("click", function () {
      const store = this.textContent.trim();
      if (store === "App Store") {
        alert("Would redirect to App Store");
      } else if (store === "Google Play") {
        alert("Would redirect to Google Play Store");
      }
    });
  });

  // Navigation menu interactions
  const navLinks = document.querySelectorAll(".nav-link");
  navLinks.forEach((link) => {
    link.addEventListener("click", function (e) {
      e.preventDefault();
      alert(`Navigation to ${this.textContent} would happen here!`);
    });
  });

  // Language selector
  const languageSelector = document.querySelector(".language-selector");
  if (languageSelector) {
    languageSelector.addEventListener("click", function () {
      alert("Language selection menu would open here!");
    });
  }

  // Profile menu
  const profileMenu = document.querySelector(".profile-menu");
  if (profileMenu) {
    profileMenu.addEventListener("click", function () {
      alert("User profile menu would open here!");
    });
  }

  // Social media icons
  const socialIcons = document.querySelectorAll(".social-icon");
  socialIcons.forEach((icon) => {
    icon.addEventListener("click", function () {
      const platform = this.textContent.trim();
      alert(`Would open ${platform} social media page`);
    });
  });

  // Footer links
  const footerLinks = document.querySelectorAll(".footer-links a");
  footerLinks.forEach((link) => {
    link.addEventListener("click", function (e) {
      e.preventDefault();
      alert(`Would navigate to ${this.textContent} page`);
    });
  });

  // Smooth scrolling for anchor links (if any are added later)
  function smoothScroll(target) {
    const element = document.querySelector(target);
    if (element) {
      element.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }
  }

  // Add some interactive hover effects
  const cards = document.querySelectorAll(".ride-card");
  cards.forEach((card) => {
    card.addEventListener("mouseenter", function () {
      this.style.transform = "translateY(-4px)";
      this.style.transition = "transform 0.3s ease";
    });

    card.addEventListener("mouseleave", function () {
      this.style.transform = "translateY(0)";
    });
  });

  // Add scroll-based animations
  const observerOptions = {
    threshold: 0.1,
    rootMargin: "0px 0px -50px 0px",
  };

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = "1";
        entry.target.style.transform = "translateY(0)";
      }
    });
  }, observerOptions);

  // Observe elements for scroll animations
  const animatedElements = document.querySelectorAll(
    ".section-title, .ride-card, .benefit-item",
  );

  animatedElements.forEach((el) => {
    el.style.opacity = "0";
    el.style.transform = "translateY(20px)";
    el.style.transition = "opacity 0.6s ease, transform 0.6s ease";
    observer.observe(el);
  });

  // Add a simple mobile menu toggle (for future mobile menu implementation)
  function createMobileMenu() {
    const header = document.querySelector(".header .container");
    const mobileMenuBtn = document.createElement("button");
    mobileMenuBtn.className = "mobile-menu-btn";
    mobileMenuBtn.innerHTML = "☰";
    mobileMenuBtn.style.cssText = `
      display: none;
      background: none;
      border: none;
      font-size: 1.5rem;
      cursor: pointer;
      color: #000;
    `;

    // Show on mobile
    const mediaQuery = window.matchMedia("(max-width: 1023px)");
    function handleMobileMenu(e) {
      if (e.matches) {
        mobileMenuBtn.style.display = "block";
        if (!header.contains(mobileMenuBtn)) {
          header.appendChild(mobileMenuBtn);
        }
      } else {
        mobileMenuBtn.style.display = "none";
      }
    }

    mediaQuery.addListener(handleMobileMenu);
    handleMobileMenu(mediaQuery);

    mobileMenuBtn.addEventListener("click", function () {
      alert("Mobile menu would toggle here!");
    });
  }

  createMobileMenu();

  console.log("WoulibX app initialized successfully!");
});
